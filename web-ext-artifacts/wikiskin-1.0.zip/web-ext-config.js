module.exports = {
	ignoreFiles: ["./icons/old/"],
	verbose: true,
	build: {
		overwriteDest: true
	},
	run: {
		firefox: "/opt/firefox-dev/firefox-bin",
		firefoxProfile: "default-release",
		pref: ["browser.privatebrowsing.autostart=false"],
		startUrl: ["https://www.wikipedia.org"]
	}
};