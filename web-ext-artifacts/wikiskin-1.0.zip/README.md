# Wikiskin
A small extension (for Firefox) that lets you use skins on Wikimedia projects without logging in.
